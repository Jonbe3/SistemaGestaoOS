import java.util.ArrayList;
import java.util.List;

public class SistemaGestaoOS {
    public static void main(String[] args) {
        Cliente c1 = new Cliente("Chico Bento", "123.456.789-00", "99999-1111");
        Tecnico t1 = new Tecnico("Neymar Jr", "Refrigeração");
        Equipamento e1 = new Equipamento("Ar Condicionado", "LG Dual Inverter", "AC12345");

        OrdemServico os1 = new OrdemServico(c1, t1, e1);
        os1.adicionarServico(new Servico("Troca de compressor", 350.0));
        os1.adicionarServico(new Servico("Carga de gás", 150.0));
        os1.atualizarStatus("Concluída");

        os1.registrar();
        c1.registrar();
        t1.registrar();

        List<OrdemServico> lista = new ArrayList<>();
        lista.add(os1);

        Relatorio.gerarRelatorioMensal(lista);
    }
}
